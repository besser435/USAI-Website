self.addEventListener("fetch", function(event) {
    console.log(`start server worker`)
});
  